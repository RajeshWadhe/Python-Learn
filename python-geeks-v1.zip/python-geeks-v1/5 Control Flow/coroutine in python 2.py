
#code 3
#demonstrate coroutine chaining
def producer(sentence,next_coroutine):
    #producer which just split strings and fee it to patten_filler coroutine
    tokens =sentence.split(" ")
    for token in tokens:
        next_coroutine.send(token)
    next_coroutine.close()

def pattern_filler(pattern="ing", next_coroutine=None):
#search for received string and if pattern matched, then send it to
#print_token() coroutine for printing
    print("Searching for {}".format(pattern))
    try:
        while True:
            token =(yield)
            if pattern in token:
                next_coroutine.send(token)
    except GeneratorExit:
        print("Done with filtering")

def print_token():
    #act as a sink, simply print received tokens
    print("I'm sink, I'll print tokens")
    try:
        while True:
            token:(yield)
            print(token)
    except GeneratorExit:
        print("DOne with printing")

pt=print_token()
pt.__next__()
pf=
