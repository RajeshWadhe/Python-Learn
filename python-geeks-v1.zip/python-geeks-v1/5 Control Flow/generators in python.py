'''
#code1
#generator function
def simpleGeneratorFun():
    yield 1
    yield 2
    yield 3
x= simpleGeneratorFun()
print(x.__next__());
print(x.__next__());
print(x.__next__());


#code2
#simple generator
def fib(limit):
    a,b=0,1
    while a<limit:
        yield a
        a, b = b, a+b
x=fib(5)
print(x.__next__());
print(x.__next__());
print(x.__next__());
print(x.__next__());
print(x.__next__());
print("\nUsing for in loop")
for i in fib(5):
      print(i)

#code3
def generator():
    t=1
    print("first result is",t)
    yield t

    t+=1
    print("second result is",t)
    yield t

    t+=1
    print("third result is",t)
    yield t

call= generator()
next(call)
next(call)
next(call)
'''
string = 'geek'
li = list(string[i] for i in range(len(string)-1,-1,-1))
print(li)

