'''
#code 1
#demonstrate coroutine execution
def print_name(prefix):
    print("searching prefix:{}".format(prefix))
    while True:
        name=(yield)
        if prefix in name:
            print(name)

#calling coroutine, nothing will happen
corou = print_name("Dear")

#This will start execution of searching prefix
corou.__next__()

#sending inputs
corou.send("Ajay")
corou.send("Dear Ajay-Atul")
corou.send("Dear Ajay")
'''

#code 2
#demonstrate closing a coroutine 
def print_name(prefix):
    print("searching prefix:{}".format(prefix))
    try:
        while True:
            name=(yield)
            if prefix in name:
                print(name)
    except GeneratorExit:
        print("Closing coroutine")

#calling coroutine, nothing will happen
corou = print_name("Dear")

#This will start execution of searching prefix
corou.__next__()

#sending inputs
corou.send("Ajay")
corou.send("Dear Ajay-Atul")
corou.send("Dear Ajay")
corou.close()
