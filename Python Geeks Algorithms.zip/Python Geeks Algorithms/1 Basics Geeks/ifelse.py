num1=34
if(num1>12):
    print("num1 is good")
elif(num1>35):
    print("num2 is not good")
else:
    print("num2 is great")
    
