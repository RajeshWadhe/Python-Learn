import math

def Main():
    num = float(input("enter a number :"))
    num = math.fabs(num)
    print(num)

if __name__ == "__main__":
    Main()
