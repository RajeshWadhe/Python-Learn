integer1=12.3456789
print("formatting in 3.2f format: ")
print("The value of integer1 is %3.2f " %integer1)
print("The value of integer1 is %3.4f " %integer1)




