s1='welcome to the geek world'
print("string with the use of single quotes ")
print(s1)

s2="i am a geek"
print("string with use of double quotes ")
print(s2)

s3='''I am a geek and I live in a world of "Geeks" '''
print("String with triple quotes ")
print(s3)

s4= '''geeks
        for
        life'''
print("\nCreating a multiline string ")
print(s4)
