Python 3.6.4 (v3.6.4:d48eceb, Dec 19 2017, 06:04:45) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> print("hello world")
hello world
>>> num-10.5
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    num-10.5
NameError: name 'num' is not defined
>>> num=10.7
>>> print(num)
10.7
>>> num='rajesh'
>>> print(num)
rajesh
>>> num="raje"
>>> print(num)
raje
>>> num
'raje'
>>> num='raja'
>>> num
'raja'
>>> num=[]
>>> num.append(21)
>>> num
[21]
>>> num.append('rajesh')
>>> num
[21, 'rajesh']
>>> num.append("String")
>>> num
[21, 'rajesh', 'String']
>>> num.append(45.67)
>>> num
[21, 'rajesh', 'String', 45.67]
>>> print(num)
[21, 'rajesh', 'String', 45.67]
>>> 
>>> #rajesh
>>> num1 = int(input("enter number"))
enter number 43
>>> num1
43
>>> num2=int(input("enter number"))
enter number 32
>>> num3=num1+num2
>>> num3
75
>>> print("product is :",num3)
product is : 75
>>> num1=34
>>> if(num1>12)
SyntaxError: invalid syntax
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/ifelse.py 
num1 is good
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/ifelse.py 
num1 is good
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/defprog.py 
hello
hello again
hello
hello again
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/MainFucntion.py 
started
enter integer: 34
34
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/MainFucntion.py 
enter integer: 67
started
enter integer: 67
67
started
enter integer: 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/MainFucntion.py 
started
enter integer: 67
67
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
0
1
2
3
4
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
0
1
2
3
4
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
0
1
2
3
4
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
0
1
2
3
4
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
0 1 2 3 4 
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
1 2 3 4 
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
0 1 2 3 4 
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/forloop.py 
1 2 3 4 
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/MathModule.py 
enter a number :56
56.0
>>> 
>>> 7/5
1.4
>>> -7/5
-1.4
>>> print(7/5)
1.4
>>> print(-7/5.0)
-1.4
>>> print(type('default string'))
<class 'str'>
>>> print(type(b'string with b'))
<class 'bytes'>
>>> print(type(u'string with b'))
<class 'str'>
>>> for x in range(1,5):print(x)
;
SyntaxError: invalid syntax
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
1
2
3
4
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
1 2 3 4 
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
name 'trying_to_check_error' is not defined error caused
>>> print false
SyntaxError: Missing parentheses in call to 'print'. Did you mean print(false)?
>>> print(false)
Traceback (most recent call last):
  File "<pyshell#42>", line 1, in <module>
    print(false)
NameError: name 'false' is not defined
>>> false ==0
Traceback (most recent call last):
  File "<pyshell#43>", line 1, in <module>
    false ==0
NameError: name 'false' is not defined
>>> print(false==0)
Traceback (most recent call last):
  File "<pyshell#44>", line 1, in <module>
    print(false==0)
NameError: name 'false' is not defined
>>> print(False==0)
True
>>> print(FALSE==0)
Traceback (most recent call last):
  File "<pyshell#46>", line 1, in <module>
    print(FALSE==0)
NameError: name 'FALSE' is not defined
>>> print(True==1)
True
>>> 
>>> print(True+True+True)
3
>>> print(True+True+False)
2
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
False
True
True
False
False
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
None
False
True
True
False
False
>>> a=[1,2,3]
>>> a
[1, 2, 3]
>>> a.append(4)
>>> a
[1, 2, 3, 4]
>>> del a[1]
>>> a
[1, 3, 4]
>>> del a
>>> a
Traceback (most recent call last):
  File "<pyshell#58>", line 1, in <module>
    a
NameError: name 'a' is not defined
>>> a=[]
>>> a
[]
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
s is part of geeksforgeeks
>>> 
 RESTART: C:/Users/rwadhe/Documents/Python Geeks Algorithms/Basics Geeks/test.py 
foris a python  keyword
>>> s="geeksforgeeks"
>>> print(s)
geeksforgeeks
>>> 
>>> print(s[0])
g
>>> print(s[-1])
s
>>> print(s[-2])
k
>>> print(s[3:7])
