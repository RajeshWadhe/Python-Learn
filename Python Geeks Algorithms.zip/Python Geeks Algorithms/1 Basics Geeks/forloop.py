for step in range(1,5):
    print(step, end=' ')
