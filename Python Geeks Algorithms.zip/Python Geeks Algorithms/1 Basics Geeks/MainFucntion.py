def getInteger():
    result = int(input("enter integer: "))
    return result

#defination of main
def Main():
    print("started")
    output = getInteger()
    print(output)

if __name__ =="__main__":
    Main()
