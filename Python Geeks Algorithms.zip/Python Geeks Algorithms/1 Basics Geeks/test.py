
#default order
s1="{} {} {}".format('geeks','for','life')
print("print string in default order: ")
print(s1)

#positional formatting
s2="{1} {0} {2}".format('geeks','for','life')
print("\nprint string in positional order")
print(s2)

#keyword formatting
s3="{l} {f} {g}".format(g='geeks', f='for', l='life')
print("\nprint string in order of keywords ")
print(s3)

#formatting og integers
s4="{0:b}".format(16)
print("\nbinary representation of 16 is ")
print(s4)

#formatting of floats
s5="{0:e}".format(165.6458)
print("\nexponent representation of 165.6458 is ")
print(s5)

#rounding of integers
s6="{0:.2f}".format(1/6)
print("\none-sixth is ")
print(s6)

#string alignment
s7="|{:<10}|{:^10}|{:>10}|".format('geeks','for','life')
print("\nleft, center, and right alignment with formatting ")
print(s7)
