def hello():
    print("hello")
    print("hello again")
hello()

#calling function
hello()
