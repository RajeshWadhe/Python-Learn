s="10010"
c=int(s,2)
print("after conversion to integer base 2: ",end=" ")
print(c)

e=float(s)
print("after converting to float: ",end=" ")
print(e)

s='4'
c=ord(s)
print("after converting char to integer",end=" ")
print(c)

c=hex(56)
print("after converting char to integer",end=" ")
print(c)

s='geeksforgeeks'
c=tuple(s)
print(c)

c=set(s)
print(c)

c=list(s)
print(c)

a=1
b=2

tup = (('a',1),('f',2),('g',3))
c=complex(1,2)
print(c)

c=str(a)
print(c)

c=dict(tup)
print(c)
