
#we use * to unpack the list so that all the elements it can be passed.
def fun(a,b,c,d):
    print(a,b,c,d)
my_list = [1,2,3,4]
fun(*my_list)


# packing
def mysum(*args):
    sum = 0
    for i in range(0,len(args)):
        sum = sum + args[i]
    return sum

print(mysum(1,2,3,4,5))
print(mysum(10,20))

#packing and unpacking
def fun1(a,b,c):
    print(a,b,c)
def fun2(*args):
    args = list(args)
    args[0]='geeksforgeeks'
    args[1]='awesome'
    fun1(*args)
fun2('hello','beautiful','world')




