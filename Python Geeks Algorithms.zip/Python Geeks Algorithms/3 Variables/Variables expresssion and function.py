x=10
print(type(x))

x=10000000000000000000000000000000000000000000000
print(type(x))

def f():
    global s
    print(s)
    s = "look for any other"
    print(s)
    s="any other 2"
    print(s)
    

#global scope
s="i love geeksforgeeks"
f()
print(s)
