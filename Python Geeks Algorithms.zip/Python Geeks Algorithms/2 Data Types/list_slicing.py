#Remove elements from list ---> Slicing of List

#creation of list
list = ['g','e','e','k','s','f','o','r','g','e','e','k','s']
print("Initial list: ")
print(list)

#print elements of range --> using slicing operation
sliced_list = list[3:8]
print("\nSlicing elements in range 3-8 :")
print(sliced_list)

#print elements from begining to a pre-defined point using slice
print("\nElements sliced till 6th from beg and last")
sliced_list = list[:4]
print(sliced_list)
sliced_list = list[:-3]
print(sliced_list)
sliced_list = list[7:]
print(sliced_list)
sliced_list = list[:]
print(sliced_list)
#print reverse list
sliced_list = list[::-1]
print(sliced_list)
