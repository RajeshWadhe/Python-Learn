import array
arr = array.array('i',[1,2,3,1,2,5])
for i in range(0,6):
    print(arr[i],end=" ")
print()

print(arr.index(2))

arr.reverse()

for i in range(0,6):
    print(arr[i],end=" ")
print()
