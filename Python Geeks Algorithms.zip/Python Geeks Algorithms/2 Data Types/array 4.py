import array


arr = array.array('i',[1,2,3,1,2,5])
print(arr.typecode)

print(arr.itemsize)

print(arr.buffer_info())

arr1 = array.array('i',[1,2,3,1,2,5])
arr2 = array.array('i',[1,2,3])
print("\nthe occurences of 1 in array : ",end=" ")
print(arr1.count(1))

arr1.extend(arr2)
for i in range(0,9):
    print(arr1[i],end=" ")
