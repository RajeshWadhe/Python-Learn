dict={}
print(dict)

dict[0]='geeks'
dict[2]='for'
dict[3]=1
print(dict)

dict['value_set']=2,3,4
print(dict)

dict[2]='welcome'
print(dict)

dict[5]={'nested':{'1':'life','2':'geeks'}}
print(dict)
