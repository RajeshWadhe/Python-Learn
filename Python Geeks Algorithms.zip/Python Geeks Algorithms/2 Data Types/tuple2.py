#concatenation of tuples
tuple1 = (0,1,2,3,4)
tuple2 = ('geeks','for','life')
tuple3 = tuple1 + tuple2
print(tuple1)
print(tuple2)
print(tuple3)

#Slicing of a tuple
#slicing with numbers
tuple1 = tuple('geeksforlife')

#removing first element
print('removing of first element')
print(tuple1[1:])

#reversing the tuple
print("\nTuple after sequence of element is reversed: ")
print(tuple1[::-1])

#printing elements of range
print("\nPrinting elements in the range 4-9: ")
print(tuple1[4:9])

#Deleting the tuple
print("\nDelete tuple : ")
tuple1 = (0,1,2,3,4)
del tuple1[1:]
print(tuple1)

