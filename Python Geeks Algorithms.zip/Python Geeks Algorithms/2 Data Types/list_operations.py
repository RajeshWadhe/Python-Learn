#create a list
list =[1,2,3,4,5,6,7,8,9,10,11,12]
print("initial list: ")
print(list)

#Remove elements from the list
list.remove(5)
print("\nList after removal")
print(list)

#remove elements from list using iterator method.
for i in range(1,5):
    list.remove(i)
print("\nlist after removing list of elements : ")
print(list)

#remove elements from the list using pop() method.
list.pop()
print("\nList after popping elements: ")
print(list)
list.pop()
print(list)

#removing specific elements from the list using pop() method.
list.pop(2)
print("\nList after popping a specific element: ")
print(list)
list.pop(6)
print(list)
