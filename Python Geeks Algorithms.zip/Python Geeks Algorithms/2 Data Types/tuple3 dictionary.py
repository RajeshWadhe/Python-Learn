#creating dictiony
dict = {}
print("\nempty dictionary")
print(dict)

#creating dictionary with integer keys
dict = {1:'geeks',2:'for',3:'geeks'}
print("\ndictionary with usage of integer keys : ")
print(dict)

#creating dictionary with mixed keys
dict = {'name':'geeks',1:[1,2,3,4,5]}
print("\ndictionary with mixed keys: ")
print(dict)

#creating dictionary with dict() method
dict1 = {1:'geeks',2:'for',3:'geeks'}
#dict1 = dict({1:'geeks',2:'for',3:'geeks'})
print("\ncreating dictionary with use of dict(): ")
#print(dict1)
print(dict1.values())

#creating dictionary with each item as a pair
#dict1 = dict([(1:'geeks'),(2:'for'),(3:'geeks')])
#dict1 = dict({1:'geeks',2:'for',3:'geeks'})
#print("\ncreating dictionary with each item as pair: ")
#print(dict1)
#print(dict1.values())

#creating a nested dictionary
dict1 = {1:{'A':'geeks','B':'for','C':'geeks'},
         2:{'D':'welcome','E':'To','F':'geeks'}}
print("\nnested dictionary")
print(dict1)
