import array

arr = array.array('i',[1,2,3,1,2,5])
li = [1,2,3]

#using fromlist() to append list at end of array
arr.fromlist(li)

#print array
print("\nmodified array is : ")
for i in range(0,9):
    print(arr[i],end=" ")

#using tolist() to convert array into list
li2 = arr.tolist()
print()
print("\nthe new created list is : ",end=" ")
for i in range(0,len(li2)):
    print(li2[i],end=" ")
