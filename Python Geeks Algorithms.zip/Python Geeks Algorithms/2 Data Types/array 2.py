import array

arr = array.array('i',[1,2,3,1,5])
for i in range(0,5):
    print(arr[i],end=" ")
print()

print(arr.pop(2))
for i in range(0,4):
    print(arr[i],end=" ")
print()

print(arr.remove(1))
for i in range(0,3):
    print(arr[i],end=" ")
print()


    
