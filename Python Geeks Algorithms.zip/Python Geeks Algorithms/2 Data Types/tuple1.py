#Addition of elements in a set

#creating an empty tuple
tuple1 = ()
print(tuple1)

#creating tuple with use of strings
tuple1 = ('geeks','for')
print("\nTuple with use of strings : ")
print(tuple1)

#creating tuple with use of list
list1 = [1,2,3,4,5,6]
print("\nTuple using List: ")
print(tuple(list1))

#creating tuple with use of loop
tuple2 = ('geeks')
n=5
print("\nTuple with a loop")
for i in range(int(n)):
    tuple2 =(tuple2,)
    print(tuple2)

#creating tuple with mixed data types
tuple2 = (5,'welcome',7,'geeks')
print("\nTuple with mixed data types : ")
print(tuple2)

#creating tuple with mixed nested tuples
tuple1 = (0,1,2,3)
tuple2 = ('python','geek')
tuple3 = tuple1 + tuple2
print("\nTuple with nested tuples: ")
print(tuple3)

#creating tuple with repetition
tuple1 = ('geeks',) * 3
print("\nTuple with repetition: ")
print(tuple1)
