dict = {5:'welcome',6:'to',7:'geeks',
        'A':{1:'geeks',2:'for',3:'geeks'},
        'B':{1:'geeks',2:'life'}}
print(dict)

del dict[6]
print(dict)

del dict['A'][2]
print(dict)

dict.pop(5)
print(dict)

dict.clear()
print(dict)
        
