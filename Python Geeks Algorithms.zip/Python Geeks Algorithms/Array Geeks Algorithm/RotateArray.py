#wap to rotate an array by d elements.

#fuction to left roate array arr[] by d
def leftRotate(arr,d,n):
    for i in range(d):
        leftRotatebyOne(arr,n)

#fuction to left roate array arr[] by 1 place
def leftRotatebyOne(arr,n):
    temp=arr[0]
    for i in range(n-1):
        arr[i]=arr[i+1]
    arr[n-1]=temp

#function to print an array
def printArray(arr,n):
        print(*arr)
        #print(*arr[2:5])

#driver program to test array
arr=[1,2,3,4,5,6,7]
leftRotate(arr,2,7)
printArray(arr,7)
