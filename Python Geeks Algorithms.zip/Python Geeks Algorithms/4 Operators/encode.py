#python code to demonstrate encode()

a='geeksforgeeks'   #string
print(a)
c=b'geeksforgeeks'  #byte object
print(c)
d=a.encode('ASCII')
print(d)
if(d==c):
    print("encoding successful")
else:
    print("encoding unsuccessful")
