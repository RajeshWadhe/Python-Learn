#enumerate()
'''
#enumerate()
for key,val in enumerate(['The','Big','Bang','Theory']):
    print(key,val)
'''

#zip()
'''
questions=['name','color','shape']
answers=['apple','red','a circle']
for questions,answers in zip(questions,answers):
           print('What is your {0}?  I am {1}.'.format(questions,answers))
'''

#items()
'''
d={"geeks":"for","only":"geeks"}
print("The key-value pair using iteritems is : ")
for i,j in d.items():
    print(i,j)
'''

#items()
'''
king={'Akbar':'The Great','Chndragupta':'The Maurya','Modi':'The Chnager'}
for key,val in king.items():
    print(key,val)
'''

#working of sorted()
'''
lis=[1,3,5,6,2,1,3]
print("The list in sorted order is : ")
for i in sorted(lis):
    print(i,end=" ")
print("The list in sorted order (without duplicates) is : ")
for i in sorted(set(lis)):
    print(i,end=" ")
'''

#using reversed()
lis=[1,3,5,6,2,1,3]
print("The list in reversed order is : ")
for i in reversed(lis):
    print(i,end=" ")






