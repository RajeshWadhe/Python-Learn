
#looping extensions
cars=["aston","audi","McLaren"]
accessories=["GPS kit","car repair-tool kit"]
prices = {1:"570000$",2:"680000$",3:"450000$", 
          4:"890000$", 5:"4500$"}
for index,c in enumerate(cars,start=1):
    print("car: %s  Price: %s" %(c,prices[index]))

for index,a in enumerate(accessories,start=1):
    print("Accessory: %s  Price: %s" %(a,prices[index+len(cars)]))
