
#C-style approach
cars=["aston","audi","McLaren"]
i=0
while(i<len(cars)):
    print(cars[i],end=" ")
    i=i+1

print()
for x in cars:
    print(x,end=" ")

print()
for y in range(len(cars)):
    print(cars[y],end=" ")

print()
for z,a in enumerate(cars):
    print(a,end=" ")

print()
for d in enumerate(cars):
    print(x[0],x[1])

print()
for d in enumerate(cars):
    print(cars)






