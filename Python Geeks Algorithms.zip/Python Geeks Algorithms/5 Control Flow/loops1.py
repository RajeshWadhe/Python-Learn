#while block
'''count=0
while(count<3):
    count=count+1
    print("hello geek")
'''

#while else block
'''
count=0
while(count<3):
    count=count+1
    print("hello geek")
else:
    print("in else block")
'''

#for in loop
#'''
print("list iteration")
m=["geeks","for","geeks"]
for i in m:
    print(i,end=" ")

print()
print("\nTuple iteration")
t=("geeks","for","geeks")
for i in t:
    print(i,end=" ")

print()
print("\nDictionary Iteration")
d=dict()
d['xyz']=123
d['abc']=345
for i in d:
    print("%s %s" %(i,d[i]))
